import socket
import threading
import pyaudio

# Configuración del servidor
server_ip = '127.0.0.1'
server_port = 5000
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((server_ip, server_port))
server.listen()

clients = []
nicknames = []

# Configuración de PyAudio para las llamadas
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
CHUNK = 1024

# Transmitir mensajes de texto a todos los clientes conectados
def broadcast(message):
    for client in clients:
        client.send(message)

# Manejo de los mensajes de cada cliente
def handle_client(client):
    while True:
        try:
            message = client.recv(1024)
            broadcast(message)
        except:
            index = clients.index(client)
            clients.remove(client)
            client.close()
            nickname = nicknames[index]
            broadcast(f'{nickname} ha salido del chat.'.encode('utf-8'))
            nicknames.remove(nickname)
            break

# Transmitir audio entre los clientes
def handle_audio(client):
    stream = pyaudio.PyAudio().open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
    while True:
        try:
            audio_data = client.recv(1024)
            if audio_data:
                for c in clients:
                    if c != client:
                        c.send(audio_data)
        except:
            stream.stop_stream()
            stream.close()
            break

# Aceptar conexiones de nuevos clientes
def receive():
    while True:
        client, address = server.accept()
        print(f"Conectado a {str(address)}")

        client.send("NICK".encode('utf-8'))
        nickname = client.recv(1024).decode('utf-8')
        nicknames.append(nickname)
        clients.append(client)

        print(f"El apodo del cliente es {nickname}")
        broadcast(f"{nickname} se ha unido al chat.".encode('utf-8'))
        client.send("Conectado al servidor.".encode('utf-8'))

        # Iniciar un hilo para manejar el chat y otro para el audio
        chat_thread = threading.Thread(target=handle_client, args=(client,))
        chat_thread.start()

        audio_thread = threading.Thread(target=handle_audio, args=(client,))
        audio_thread.start()

print("Servidor corriendo...")
receive()
